#!/bin/bash
# fiberdoc-wget-update.sh v1.3
# Actualiza o FiberDoc a partir de um pacote ZIP remoto.
# Compatível com bash 3.x, 4.x e 5.x (Debian, Ubuntu, CentOS).
#
# Uso:
#   bash fiberdoc-wget-update.sh <URL_DO_PACOTE_ZIP>
#
# Exemplo:
#   bash fiberdoc-wget-update.sh https://releases.exemplo.com/fiberdoc-v6.5.10.zip

set -euo pipefail

# ── Configuração ──────────────────────────────────────────────────────────────
FIBERDOC_DIR="${FIBERDOC_DIR:-/opt/fiberdoc}"
FIBERDOC_SERVICE="${FIBERDOC_SERVICE:-fiberdoc}"
BACKUP_DIR="${FIBERDOC_DIR}/backups"
TMP_DIR="/tmp/fiberdoc-update-$$"
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
UPDATE_URL="${1:-${FIBERDOC_UPDATE_URL:-}}"

# ── Cores ─────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log_step()  { echo -e "\n${CYAN}${BOLD}▶ $1${NC}"; }
log_ok()    { echo -e "  ${GREEN}✓${NC} $1"; }
log_warn()  { echo -e "  ${YELLOW}⚠${NC}  $1"; }
log_error() { echo -e "  ${RED}✗${NC}  $1" >&2; }
log_info()  { echo -e "  ${CYAN}ℹ${NC}  $1"; }

# ── Banner ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}============================================================${NC}"
echo -e "${CYAN}${BOLD}  FiberDoc — Script de Actualização v1.3${NC}"
echo -e "${BOLD}============================================================${NC}"
echo ""

# ── Verificações iniciais ─────────────────────────────────────────────────────
if [ "$(id -u)" -ne 0 ]; then
  log_error "Este script deve ser executado como root."
  echo "       Execute: sudo bash fiberdoc-wget-update.sh <URL>"
  exit 1
fi

if [ -z "${UPDATE_URL}" ]; then
  log_error "URL do pacote de actualização não fornecida."
  echo ""
  echo "  Uso: bash fiberdoc-wget-update.sh <URL_DO_PACOTE_ZIP>"
  echo ""
  echo "  Exemplo:"
  echo "    bash fiberdoc-wget-update.sh https://releases.exemplo.com/fiberdoc-v6.5.10.zip"
  exit 1
fi

# Verificar wget ou curl
DOWNLOADER=""
if command -v wget >/dev/null 2>&1; then
  DOWNLOADER="wget"
  log_ok "wget encontrado."
elif command -v curl >/dev/null 2>&1; then
  DOWNLOADER="curl"
  log_ok "curl encontrado (usado como alternativa ao wget)."
else
  log_error "Nem wget nem curl estão instalados."
  echo "       Instale com: apt-get install -y wget"
  exit 1
fi

# Verificar unzip
if ! command -v unzip >/dev/null 2>&1; then
  log_error "unzip não está instalado."
  echo "       Instale com: apt-get install -y unzip"
  exit 1
fi
log_ok "unzip encontrado."

# Verificar instalação existente
if [ ! -d "${FIBERDOC_DIR}" ]; then
  log_warn "Directório ${FIBERDOC_DIR} nao existe. Sera criado (instalacao nova)."
fi

mkdir -p "${FIBERDOC_DIR}" "${BACKUP_DIR}" "${TMP_DIR}"
log_ok "Verificacoes concluidas."

# ── 1. Download do pacote ─────────────────────────────────────────────────────
log_step "[1/7] A fazer download do pacote de actualizacao..."
log_info "URL: ${UPDATE_URL}"

ZIP_FILE="${TMP_DIR}/fiberdoc-update.zip"

if [ "${DOWNLOADER}" = "wget" ]; then
  wget \
    --progress=bar:force \
    --timeout=120 \
    --tries=3 \
    --output-document="${ZIP_FILE}" \
    "${UPDATE_URL}" 2>&1 \
    || { log_error "Falha no download. Verifique a URL e a ligacao a internet."; exit 1; }
else
  curl \
    --location \
    --progress-bar \
    --connect-timeout 30 \
    --max-time 300 \
    --retry 3 \
    --output "${ZIP_FILE}" \
    "${UPDATE_URL}" \
    || { log_error "Falha no download. Verifique a URL e a ligacao a internet."; exit 1; }
fi

if [ ! -f "${ZIP_FILE}" ] || [ ! -s "${ZIP_FILE}" ]; then
  log_error "Ficheiro descarregado esta vazio ou nao existe."
  exit 1
fi

ZIP_SIZE=$(du -sh "${ZIP_FILE}" | cut -f1)
log_ok "Download concluido. Tamanho: ${ZIP_SIZE}"

# ── 2. Validar o ZIP ──────────────────────────────────────────────────────────
log_step "[2/7] A validar o pacote..."

if ! unzip -t "${ZIP_FILE}" >/dev/null 2>&1; then
  log_error "O ficheiro descarregado nao e um ZIP valido."
  echo "       Verifique se a URL aponta para um ficheiro .zip correcto."
  exit 1
fi

# Verificar conteudo minimo esperado
if ! unzip -l "${ZIP_FILE}" 2>/dev/null | grep -q "dist/index.js"; then
  log_warn "dist/index.js nao encontrado no ZIP. O pacote pode estar incompleto."
  log_warn "Continuar mesmo assim? Digite s para continuar ou qualquer outra tecla para cancelar:"
  read -r CONFIRM
  if [ "${CONFIRM}" != "s" ] && [ "${CONFIRM}" != "S" ]; then
    log_error "Actualizacao cancelada pelo utilizador."
    exit 1
  fi
fi

log_ok "Pacote ZIP valido."

# ── 3. Backup da instalação actual ────────────────────────────────────────────
log_step "[3/7] A criar backup da instalacao actual..."

BACKUP_FILE=""
if [ -f "${FIBERDOC_DIR}/dist/index.js" ]; then
  BACKUP_FILE="${BACKUP_DIR}/fiberdoc_backup_${TIMESTAMP}.tar.gz"
  tar -czf "${BACKUP_FILE}" \
    -C "${FIBERDOC_DIR}" \
    --exclude="backups" \
    --exclude="node_modules" \
    --exclude="*.log" \
    . 2>/dev/null || true
  BACKUP_SIZE=$(du -sh "${BACKUP_FILE}" | cut -f1)
  log_ok "Backup criado: ${BACKUP_FILE} (${BACKUP_SIZE})"
else
  log_info "Nenhuma instalacao anterior encontrada — backup ignorado."
fi

# Guardar DATABASE_URL antes de qualquer operacao
DB_URL_SAVED=""
# 1. Variavel de ambiente actual
if [ -n "${DATABASE_URL:-}" ]; then
  DB_URL_SAVED="${DATABASE_URL}"
  log_info "DATABASE_URL guardada a partir da variavel de ambiente."
fi
# 2. Ficheiro .env
if [ -z "${DB_URL_SAVED}" ] && [ -f "${FIBERDOC_DIR}/.env" ]; then
  DB_URL_SAVED=$(grep '^DATABASE_URL=' "${FIBERDOC_DIR}/.env" 2>/dev/null \
                 | head -1 | sed 's/^DATABASE_URL=//' | tr -d '"' || true)
  if [ -n "${DB_URL_SAVED}" ]; then
    log_info "DATABASE_URL guardada a partir do .env."
  fi
fi
# 3. Servico systemd
if [ -z "${DB_URL_SAVED}" ]; then
  SERVICE_FILE_CHECK="/etc/systemd/system/${FIBERDOC_SERVICE}.service"
  if [ -f "${SERVICE_FILE_CHECK}" ]; then
    DB_URL_SAVED=$(grep '^Environment=DATABASE_URL=' "${SERVICE_FILE_CHECK}" 2>/dev/null \
                   | head -1 | sed 's/^Environment=DATABASE_URL=//' || true)
    if [ -n "${DB_URL_SAVED}" ]; then
      log_info "DATABASE_URL guardada a partir do servico systemd."
    fi
  fi
fi

# ── 4. Parar o serviço ────────────────────────────────────────────────────────
log_step "[4/7] A parar o servico ${FIBERDOC_SERVICE}..."

SERVICE_WAS_RUNNING=false
if systemctl is-active --quiet "${FIBERDOC_SERVICE}" 2>/dev/null; then
  systemctl stop "${FIBERDOC_SERVICE}"
  SERVICE_WAS_RUNNING=true
  log_ok "Servico parado."
else
  log_info "Servico nao estava em execucao."
fi

# ── 5. Extrair e aplicar o pacote ─────────────────────────────────────────────
log_step "[5/7] A extrair e aplicar o pacote..."

EXTRACT_DIR="${TMP_DIR}/extracted"
mkdir -p "${EXTRACT_DIR}"
unzip -q "${ZIP_FILE}" -d "${EXTRACT_DIR}"

# Detectar se o ZIP tem uma pasta raiz
INNER_DIR=$(find "${EXTRACT_DIR}" -maxdepth 1 -mindepth 1 -type d | head -1)
SOURCE_DIR=""
if [ -n "${INNER_DIR}" ] && [ -f "${INNER_DIR}/dist/index.js" ]; then
  SOURCE_DIR="${INNER_DIR}"
  log_info "Pasta raiz detectada: $(basename "${INNER_DIR}")"
elif [ -f "${EXTRACT_DIR}/dist/index.js" ]; then
  SOURCE_DIR="${EXTRACT_DIR}"
else
  log_error "Estrutura do ZIP nao reconhecida. Esperado: dist/index.js na raiz."
  exit 1
fi

# Preservar ficheiros criticos antes do rsync
ENV_BACKUP="${TMP_DIR}/env_backup"
mkdir -p "${ENV_BACKUP}"

# Remover symlink quebrado se existir
if [ -L "${FIBERDOC_DIR}/.env" ] && [ ! -e "${FIBERDOC_DIR}/.env" ]; then
  rm -f "${FIBERDOC_DIR}/.env"
  log_info "Symlink quebrado .env removido."
fi

if [ -f "${FIBERDOC_DIR}/.env" ]; then
  cp "${FIBERDOC_DIR}/.env" "${ENV_BACKUP}/.env"
  log_info ".env guardado para preservacao."
fi

if [ -d "${FIBERDOC_DIR}/local-uploads" ]; then
  cp -r "${FIBERDOC_DIR}/local-uploads" "${ENV_BACKUP}/local-uploads" 2>/dev/null || true
fi

# Copiar ficheiros (preservar .env, backups e pastas residuais)
rsync -a --delete \
  --exclude=".env" \
  --exclude="backups/" \
  --exclude="node_modules/" \
  --exclude="*.log" \
  --exclude="local-uploads/" \
  --exclude="local-backups/" \
  --exclude=".manus-logs/" \
  --exclude="fiberdoc-v*/" \
  --filter="protect fiberdoc-v*/" \
  --filter="protect .manus-logs/" \
  "${SOURCE_DIR}/" "${FIBERDOC_DIR}/" 2>&1 | grep -v 'cannot delete' || true

# Restaurar .env
if [ -f "${ENV_BACKUP}/.env" ]; then
  if [ -L "${FIBERDOC_DIR}/.env" ]; then
    rm -f "${FIBERDOC_DIR}/.env"
  fi
  cp "${ENV_BACKUP}/.env" "${FIBERDOC_DIR}/.env"
  log_ok ".env restaurado com sucesso."
elif [ -n "${DB_URL_SAVED}" ]; then
  # Recriar .env com DATABASE_URL guardada
  echo "DATABASE_URL=${DB_URL_SAVED}" > "${FIBERDOC_DIR}/.env"
  log_ok ".env recriado com DATABASE_URL guardada."
fi

if [ -d "${ENV_BACKUP}/local-uploads" ]; then
  cp -r "${ENV_BACKUP}/local-uploads" "${FIBERDOC_DIR}/" 2>/dev/null || true
fi

log_ok "Ficheiros aplicados em ${FIBERDOC_DIR}."

# ── 6. Instalar dependências ──────────────────────────────────────────────────
log_step "[6/7] A instalar dependencias..."

cd "${FIBERDOC_DIR}"

INSTALL_OK=false

if command -v npm >/dev/null 2>&1; then
  log_info "A instalar dependencias com npm..."
  if npm install --omit=dev --ignore-scripts 2>&1 | tail -5; then
    log_ok "Dependencias instaladas com npm."
    INSTALL_OK=true
  else
    log_warn "npm install falhou. A tentar pnpm..."
  fi
fi

if [ "${INSTALL_OK}" = "false" ] && command -v pnpm >/dev/null 2>&1; then
  log_info "A instalar dependencias com pnpm..."
  if pnpm install --prod --no-frozen-lockfile --ignore-scripts 2>&1 | tail -5; then
    log_ok "Dependencias instaladas com pnpm."
    INSTALL_OK=true
  else
    log_warn "pnpm install tambem falhou."
  fi
fi

if [ "${INSTALL_OK}" = "false" ]; then
  log_warn "Nao foi possivel instalar dependencias automaticamente."
  log_warn "Execute manualmente: cd ${FIBERDOC_DIR} && npm install --omit=dev"
fi

# ── 6b. Migração SQL (se existir migrate.sql no pacote) ───────────────────────
MIGRATE_SQL=""
for candidate in \
  "${FIBERDOC_DIR}/migrate.sql" \
  "${FIBERDOC_DIR}/migrate-latest.sql" \
  "${SOURCE_DIR}/migrate.sql" \
  "${SOURCE_DIR}/migrate-latest.sql"; do
  if [ -f "${candidate}" ]; then
    MIGRATE_SQL="${candidate}"
    break
  fi
done

if [ -n "${MIGRATE_SQL}" ]; then
  log_info "Ficheiro de migracao SQL encontrado: ${MIGRATE_SQL}"

  DB_URL="${DB_URL_SAVED:-}"
  if [ -z "${DB_URL}" ] && [ -f "${FIBERDOC_DIR}/.env" ]; then
    DB_URL=$(grep '^DATABASE_URL=' "${FIBERDOC_DIR}/.env" 2>/dev/null \
             | head -1 | sed 's/^DATABASE_URL=//' | tr -d '"' || true)
  fi

  if [ -z "${DB_URL}" ]; then
    log_warn "DATABASE_URL nao configurada — migracao SQL ignorada."
    log_warn "Execute manualmente apos configurar:"
    log_warn "  mysql -h HOST -P PORTA -u USER -pSENHA DBNAME < ${MIGRATE_SQL}"
  elif command -v mysql >/dev/null 2>&1; then
    DB_CLEAN=$(echo "${DB_URL}" | sed 's|mysql://||' | sed 's|?.*||')
    DB_USER=$(echo "${DB_CLEAN}" | sed 's|:.*||')
    DB_REST=$(echo "${DB_CLEAN}" | sed "s|${DB_USER}:||")
    DB_PASS=$(echo "${DB_REST}" | sed 's|@.*||')
    DB_HOSTPORT=$(echo "${DB_REST}" | sed "s|${DB_PASS}@||" | sed 's|/.*||')
    DB_NAME=$(echo "${DB_REST}" | sed "s|${DB_PASS}@${DB_HOSTPORT}/||")
    DB_HOST=$(echo "${DB_HOSTPORT}" | cut -d: -f1)
    DB_PORT=$(echo "${DB_HOSTPORT}" | cut -d: -f2)
    DB_PORT="${DB_PORT:-3306}"

    SSL_OPT=""
    if [ "${DB_PORT}" = "4000" ] || echo "${DB_HOST}" | grep -qi "tidb\|cloud\|aws\|azure\|gcp"; then
      SSL_OPT="--ssl-mode=REQUIRED"
    fi

    log_info "A aplicar migracao SQL em ${DB_HOST}:${DB_PORT}/${DB_NAME}..."
    if mysql -h "${DB_HOST}" -P "${DB_PORT}" -u "${DB_USER}" "-p${DB_PASS}" \
             ${SSL_OPT} "${DB_NAME}" < "${MIGRATE_SQL}" 2>&1; then
      log_ok "Migracao SQL aplicada com sucesso."
    else
      log_warn "Falha ao aplicar migracao. Execute manualmente:"
      log_warn "  mysql -h ${DB_HOST} -P ${DB_PORT} -u ${DB_USER} -pSENHA ${DB_NAME} < ${MIGRATE_SQL}"
    fi
  else
    log_warn "mysql-client nao encontrado — migracao ignorada."
    log_warn "Instale com: apt-get install -y mysql-client"
    log_warn "Depois execute: mysql ... < ${MIGRATE_SQL}"
  fi
else
  log_info "Nenhum ficheiro de migracao SQL encontrado — ignorado."
fi

# ── 7. Reiniciar o serviço ────────────────────────────────────────────────────
log_step "[7/7] A reiniciar o servico ${FIBERDOC_SERVICE}..."

systemctl daemon-reload

SERVICE_FILE="/etc/systemd/system/${FIBERDOC_SERVICE}.service"
if [ -f "${SERVICE_FILE}" ]; then
  systemctl restart "${FIBERDOC_SERVICE}" || true
  sleep 5
  if systemctl is-active --quiet "${FIBERDOC_SERVICE}"; then
    log_ok "Servico reiniciado com sucesso!"
  else
    log_warn "Servico nao iniciou. Verifique os logs:"
    log_warn "  journalctl -u ${FIBERDOC_SERVICE} -n 30 --no-pager"
    log_warn ""
    log_warn "Se aparecer erro 502, execute:"
    log_warn "  bash ${FIBERDOC_DIR}/scripts/fiberdoc-fix-502.sh"
  fi
else
  log_warn "Ficheiro de servico systemd nao encontrado: ${SERVICE_FILE}"
  log_warn "O servico nao foi reiniciado automaticamente."
  if [ "${SERVICE_WAS_RUNNING}" = "true" ]; then
    log_warn "O servico estava em execucao antes da actualizacao."
    log_warn "Inicie manualmente: systemctl start ${FIBERDOC_SERVICE}"
  fi
fi

# ── Limpeza ───────────────────────────────────────────────────────────────────
rm -rf "${TMP_DIR}" 2>/dev/null || true

# ── Resumo final ──────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}============================================================${NC}"

if systemctl is-active --quiet "${FIBERDOC_SERVICE}" 2>/dev/null; then
  echo -e "${GREEN}${BOLD}  FiberDoc actualizado com sucesso!${NC}"
else
  echo -e "${YELLOW}${BOLD}  FiberDoc actualizado — servico pode precisar de atencao${NC}"
  echo ""
  echo -e "  Se aparecer erro 502, execute:"
  echo -e "    ${CYAN}bash ${FIBERDOC_DIR}/scripts/fiberdoc-fix-502.sh${NC}"
fi

echo ""
if [ -n "${BACKUP_FILE}" ]; then
  echo -e "  Backup anterior: ${BACKUP_FILE}"
fi
echo -e "  Directorio:      ${FIBERDOC_DIR}"
echo -e "  Servico:         ${FIBERDOC_SERVICE}"
echo -e "  Data/Hora:       $(date '+%d/%m/%Y %H:%M:%S')"
echo ""
echo -e "  Para verificar o estado:"
echo -e "    systemctl status ${FIBERDOC_SERVICE}"
echo -e "    journalctl -u ${FIBERDOC_SERVICE} -f"
echo -e "${BOLD}============================================================${NC}"
echo ""
